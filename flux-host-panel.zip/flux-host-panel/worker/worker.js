'use strict';
// Flux Host beta worker. Listens on 127.0.0.1 only. Runs each bot in its own limited Docker container.
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const { execFile } = require('child_process');

const KEY = process.env.WORKER_KEY || '';
const PORT = +process.env.WORKER_PORT || 3939;
const BASE = process.env.DATA_DIR || '/var/lib/fluxhost';
const IMAGE = process.env.NODE_IMAGE || 'node:20-alpine';
if (KEY.length < 24) { console.error('WORKER_KEY must be at least 24 characters'); process.exit(1); }

const ID = /^[a-f0-9]{8}$/;
const MAIN = /^(?!.*\.\.)[A-Za-z0-9_\-\/]{1,60}\.js$/;
const FILE = /^[A-Za-z0-9_\-][A-Za-z0-9_.\-]{0,59}$/;
const ENVK = /^[A-Za-z_][A-Za-z0-9_]{0,63}$/;
const D = { servers: path.join(BASE, 'servers'), env: path.join(BASE, 'env'), meta: path.join(BASE, 'meta') };
for (const d of Object.values(D)) fs.mkdirSync(d, { recursive: true, mode: 0o755 });

const sdir = id => path.join(D.servers, id), envf = id => path.join(D.env, id + '.env'), metaf = id => path.join(D.meta, id + '.json');
const cname = id => 'flux-' + id;
const docker = (...a) => new Promise(r => execFile('docker', a, { timeout: 180000, maxBuffer: 8e6 },
  (e, o, s) => r({ ok: !e, out: (o || '') + (s || '') })));
const readMeta = id => { try { return JSON.parse(fs.readFileSync(metaf(id), 'utf8')); } catch { return null; } };
const own = p => { try { fs.chownSync(p, 1000, 1000); } catch {} };

const STARTER_JS = `const { Client, GatewayIntentBits } = require('discord.js');
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
client.once('ready', () => console.log('Logged in as ' + client.user.tag));
if (!process.env.DISCORD_TOKEN) { console.log('Set DISCORD_TOKEN in Variables, then restart.'); process.exit(1); }
client.login(process.env.DISCORD_TOKEN);
`;
const STARTER_PKG = JSON.stringify({ name: 'my-bot', version: '1.0.0', main: 'index.js', dependencies: { 'discord.js': '^14.16.3' } }, null, 2);

function redact(text, id) {
  try {
    for (const line of fs.readFileSync(envf(id), 'utf8').split('\n')) {
      const v = line.slice(line.indexOf('=') + 1);
      if (v.length >= 6) text = text.split(v).join('[hidden]');
    }
  } catch {}
  return text;
}

async function run(id, main) {
  const dir = sdir(id);
  if (!fs.existsSync(envf(id))) fs.writeFileSync(envf(id), '', { mode: 0o600 });
  await docker('rm', '-f', cname(id));
  const script = '[ -f package.json ] && npm install --omit=dev --ignore-scripts --no-audit --no-fund; exec node ' + main;
  return docker('run', '-d', '--name', cname(id),
    '--memory', '512m', '--memory-swap', '512m', '--cpus', '0.5', '--pids-limit', '128',
    '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--user', '1000:1000',
    '-v', dir + ':/app', '-w', '/app', '-e', 'HOME=/app', '--env-file', envf(id), IMAGE, 'sh', '-c', script);
}

async function status(id) {
  const m = readMeta(id);
  const r = await docker('inspect', '-f', '{{.State.Status}}|{{.State.ExitCode}}', cname(id));
  let state = 'offline', exit = null, stats = null;
  if (r.ok) { const [s, c] = r.out.trim().split('|'); state = s; exit = +c; }
  if (state === 'running') {
    const st = await docker('stats', '--no-stream', '--format', '{{.CPUPerc}}|{{.MemUsage}}', cname(id));
    if (st.ok) { const [cpu, mem] = st.out.trim().split('|'); stats = { cpu, mem }; }
  }
  return { state, exit, stats, expires: m ? m.expires : null };
}

const handlers = {
  async create(id, b) {
    if (fs.existsSync(metaf(id))) return [409, { error: 'exists' }];
    fs.mkdirSync(sdir(id), { mode: 0o755 });
    fs.writeFileSync(path.join(sdir(id), 'index.js'), STARTER_JS);
    fs.writeFileSync(path.join(sdir(id), 'package.json'), STARTER_PKG);
    for (const f of fs.readdirSync(sdir(id))) own(path.join(sdir(id), f));
    own(sdir(id));
    fs.writeFileSync(envf(id), '', { mode: 0o600 });
    fs.writeFileSync(metaf(id), JSON.stringify({ expires: +b.expires, main: 'index.js' }));
    return [200, { ok: true }];
  },
  async start(id, b) {
    const m = readMeta(id); if (!m) return [404, { error: 'unknown server' }];
    if (Date.now() / 1000 >= m.expires) return [410, { error: 'Allocation expired. Create a new one.' }];
    const main = b.main || m.main;
    if (!MAIN.test(main)) return [400, { error: 'Invalid startup file' }];
    m.main = main; fs.writeFileSync(metaf(id), JSON.stringify(m));
    const r = await run(id, main);
    return r.ok ? [200, { ok: true }] : [500, { error: 'Docker error: ' + r.out.slice(0, 300) }];
  },
  async delete(id) {
    await docker('rm', '-f', cname(id));
    for (const p of [sdir(id), envf(id), metaf(id)]) fs.rmSync(p, { recursive: true, force: true });
    return [200, { ok: true }];
  },
  async stop(id) { const r = await docker('stop', '-t', '10', cname(id)); return [200, { ok: r.ok || /No such/.test(r.out) }]; },
  async status(id) { return readMeta(id) ? [200, await status(id)] : [404, { error: 'unknown server' }]; },
  async logs(id) {
    const r = await docker('logs', '--tail', '300', cname(id));
    return [200, { logs: r.ok ? redact(r.out, id).slice(-60000) : 'No logs yet. Start the server first.' }];
  },
  async files(id) {
    const out = fs.readdirSync(sdir(id), { withFileTypes: true }).filter(e => e.isFile() && FILE.test(e.name))
      .map(e => ({ name: e.name, size: fs.statSync(path.join(sdir(id), e.name)).size }));
    return [200, { files: out }];
  },
  async file(id, b, name) {
    if (!FILE.test(name || '')) return [400, { error: 'Invalid file name' }];
    const p = path.join(sdir(id), name);
    if (!fs.existsSync(p) || fs.lstatSync(p).isSymbolicLink() || !fs.statSync(p).isFile()) return [404, { error: 'not found' }];
    if (fs.statSync(p).size > 200000) return [413, { error: 'File too large to edit' }];
    return [200, { content: fs.readFileSync(p, 'utf8') }];
  },
  async save(id, b) {
    if (!FILE.test(b.name || '') || typeof b.content !== 'string') return [400, { error: 'Invalid file name' }];
    if (b.content.length > 200000) return [413, { error: 'File too large (200 KB max)' }];
    const p = path.join(sdir(id), b.name);
    if (fs.existsSync(p) && fs.lstatSync(p).isSymbolicLink()) return [400, { error: 'Invalid file' }];
    if (fs.readdirSync(sdir(id)).length > 200) return [413, { error: 'Too many files' }];
    fs.writeFileSync(p, b.content); own(p);
    return [200, { ok: true }];
  },
  async setenv(id, b) {
    const lines = [];
    for (const raw of String(b.text || '').split('\n')) {
      const line = raw.trim(); if (!line || line[0] === '#') continue;
      const i = line.indexOf('='); if (i < 1) return [400, { error: 'Use KEY=value, one per line' }];
      const k = line.slice(0, i).trim(), v = line.slice(i + 1).trim();
      if (!ENVK.test(k)) return [400, { error: 'Bad variable name: ' + k.slice(0, 30) }];
      lines.push(k + '=' + v);
    }
    if (lines.length > 50) return [400, { error: 'Max 50 variables' }];
    fs.writeFileSync(envf(id), lines.join('\n') + '\n', { mode: 0o600 });
    return [200, { ok: true }];
  },
  async envkeys(id) {
    let keys = []; try { keys = fs.readFileSync(envf(id), 'utf8').split('\n').filter(Boolean).map(l => l.split('=')[0]); } catch {}
    return [200, { keys }];
  },
};
const ROUTES = { 'POST create': 'create', 'POST delete': 'delete', 'POST start': 'start', 'POST stop': 'stop', 'GET status': 'status', 'GET logs': 'logs',
  'GET files': 'files', 'GET file': 'file', 'POST save': 'save', 'POST setenv': 'setenv', 'GET envkeys': 'envkeys' };

const keyBuf = Buffer.from(KEY);
http.createServer(async (q, s) => {
  const send = (c, o) => { s.writeHead(c, { 'content-type': 'application/json' }); s.end(JSON.stringify(o)); };
  try {
    const got = Buffer.from(String(q.headers['x-worker-key'] || ''));
    if (got.length !== keyBuf.length || !crypto.timingSafeEqual(got, keyBuf)) return send(401, { error: 'unauthorized' });
    let body = ''; for await (const c of q) { body += c; if (body.length > 1e6) return send(413, { error: 'too large' }); }
    const b = body ? JSON.parse(body) : {};
    const [act, id, name] = new URL(q.url, 'http://x').pathname.split('/').filter(Boolean).map(decodeURIComponent);
    if (act === 'health') return send(200, { ok: true });
    const h = ROUTES[q.method + ' ' + act];
    if (!h) return send(404, { error: 'no such route' });
    if (!ID.test(id || '')) return send(400, { error: 'bad id' });
    if (h !== 'create' && !readMeta(id)) return send(404, { error: 'unknown server' });
    const [code, out] = await handlers[h](id, b, name);
    send(code, out);
  } catch (e) { console.error(e.message); send(500, { error: 'worker error' }); }
}).listen(PORT, '127.0.0.1', () => console.log('Flux worker on 127.0.0.1:' + PORT));

// Expiry enforcement: runs even when nobody is logged in.
setInterval(async () => {
  const now = Date.now() / 1000;
  for (const f of fs.readdirSync(D.meta)) {
    const id = f.replace('.json', ''); const m = readMeta(id);
    if (!ID.test(id) || !m || now < m.expires) continue;
    const r = await docker('rm', '-f', cname(id));
    if (r.ok) console.log('expired and removed', id);
  }
}, 30000);
