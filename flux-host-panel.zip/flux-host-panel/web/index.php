<?php
declare(strict_types=1);
// Flux Host beta: auth, server records, and a thin authenticated bridge to the worker.
$cfg = [
  'worker' => getenv('WORKER_URL') ?: 'http://127.0.0.1:3939',
  'key'    => getenv('WORKER_KEY') ?: '',
  'hours'  => (int)(getenv('ALLOC_HOURS') ?: 12),
  'max'    => (int)(getenv('MAX_ACTIVE') ?: 1),
  'data'   => getenv('WEB_DATA') ?: __DIR__ . '/../data',
  'origin' => rtrim(getenv('SITE_ORIGIN') ?: '', '/'),
];
if (!is_dir($cfg['data'])) mkdir($cfg['data'], 0750, true);

$https = !empty($_SERVER['HTTPS']) || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') || (($_SERVER['HTTP_CF_VISITOR'] ?? '') !== '' && str_contains($_SERVER['HTTP_CF_VISITOR'], 'https'));
if ($cfg['origin'] !== '' && ($_SERVER['HTTP_ORIGIN'] ?? '') === $cfg['origin']) {
  header('Access-Control-Allow-Origin: ' . $cfg['origin']);
  header('Access-Control-Allow-Credentials: true');
  header('Access-Control-Allow-Headers: Content-Type, X-CSRF');
  header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
  header('Vary: Origin');
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }
header('X-Content-Type-Options: nosniff');
session_set_cookie_params(['httponly' => true, 'samesite' => $https ? 'None' : 'Lax', 'secure' => $https, 'lifetime' => 86400 * 14]);
session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));

$db = new PDO('sqlite:' . $cfg['data'] . '/flux.db', null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
$db->exec('PRAGMA foreign_keys=ON');
$db->exec('CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, hash TEXT NOT NULL, created INTEGER NOT NULL)');
$db->exec('CREATE TABLE IF NOT EXISTS servers(id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, name TEXT NOT NULL, main TEXT NOT NULL, created INTEGER NOT NULL, expires INTEGER NOT NULL)');
$db->exec('CREATE TABLE IF NOT EXISTS fails(ip TEXT NOT NULL, ts INTEGER NOT NULL)');

function out(array $d, int $c = 200): never { http_response_code($c); header('Content-Type: application/json'); echo json_encode($d); exit; }
function W(string $m, string $p, ?array $b = null): array {
  global $cfg;
  $ch = curl_init($cfg['worker'] . $p);
  $o = [CURLOPT_CUSTOMREQUEST => $m, CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 150, CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_HTTPHEADER => ['X-Worker-Key: ' . $cfg['key'], 'Content-Type: application/json']];
  if ($b !== null) $o[CURLOPT_POSTFIELDS] = json_encode($b);
  curl_setopt_array($ch, $o);
  $r = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
  if ($c === 0) return [0, ['error' => 'Worker is not reachable, so nothing was started.']];
  return [$c, json_decode((string)$r, true) ?: []];
}
function body(): array { return json_decode(file_get_contents('php://input') ?: '{}', true) ?: []; }
function need_user(): int { if (empty($_SESSION['uid'])) out(['error' => 'Please log in'], 401); return (int)$_SESSION['uid']; }
function own(string $id): array {
  global $db; $uid = need_user();
  $s = $db->prepare('SELECT * FROM servers WHERE id=? AND user_id=?'); $s->execute([$id, $uid]);
  $r = $s->fetch(); if (!$r) out(['error' => 'Server not found'], 404); return $r;
}
function relay(array $r): never { out($r[1], $r[0] ?: 503); }

$a = $_GET['a'] ?? '';
if ($a !== '') {
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && !hash_equals($_SESSION['csrf'], $_SERVER['HTTP_X_CSRF'] ?? '')) out(['error' => 'Bad session token, reload the page'], 403);
  $b = body(); $id = (string)($_GET['id'] ?? $b['id'] ?? '');
  switch ($a) {
    case 'register': case 'login':
      $u = trim((string)($b['username'] ?? '')); $p = (string)($b['password'] ?? '');
      $ip = $_SERVER['REMOTE_ADDR'] ?? '';
      if ($a === 'register') {
        if (!preg_match('/^[A-Za-z0-9_]{3,24}$/', $u)) out(['error' => 'Username: 3-24 letters, numbers or _'], 422);
        if (strlen($p) < 8) out(['error' => 'Password must be at least 8 characters'], 422);
        try { $db->prepare('INSERT INTO users(username,hash,created) VALUES(?,?,?)')->execute([$u, password_hash($p, PASSWORD_DEFAULT), time()]); }
        catch (PDOException) { out(['error' => 'Username already taken'], 409); }
        $uid = (int)$db->lastInsertId();
      } else {
        $db->prepare('DELETE FROM fails WHERE ts<?')->execute([time() - 900]);
        $n = $db->prepare('SELECT COUNT(*) c FROM fails WHERE ip=?'); $n->execute([$ip]);
        if ((int)$n->fetch()['c'] >= 10) out(['error' => 'Too many attempts. Try again in 15 minutes.'], 429);
        $s = $db->prepare('SELECT * FROM users WHERE username=?'); $s->execute([$u]); $row = $s->fetch();
        if (!$row || !password_verify($p, $row['hash'])) { $db->prepare('INSERT INTO fails VALUES(?,?)')->execute([$ip, time()]); out(['error' => 'Wrong username or password'], 401); }
        $uid = (int)$row['id'];
      }
      session_regenerate_id(true); $_SESSION['uid'] = $uid; $_SESSION['name'] = $u; $_SESSION['csrf'] = bin2hex(random_bytes(16));
      out(['ok' => true]);
    case 'me': out(['user' => $_SESSION['name'] ?? null, 'csrf' => $_SESSION['csrf'], 'hours' => $cfg['hours']]);
    case 'logout': session_destroy(); out(['ok' => true]);
    case 'delete':
      $s = own($id); [$c, $r] = W('POST', '/delete/' . $id, []);
      if ($c !== 200) out(['error' => $r['error'] ?? 'Worker failed to delete the server'], 502);
      $db->prepare('DELETE FROM servers WHERE id=?')->execute([$id]); out(['ok' => true]);
    case 'servers':
      $uid = need_user(); $s = $db->prepare('SELECT id,name,main,created,expires FROM servers WHERE user_id=? ORDER BY created DESC'); $s->execute([$uid]);
      $rows = $s->fetchAll();
      foreach ($rows as &$r) { [$c, $st] = W('GET', '/status/' . $r['id']); $r['state'] = $c === 200 ? $st['state'] : 'unknown'; }
      out(['servers' => $rows, 'now' => time()]);
    case 'create':
      $uid = need_user(); $name = trim((string)($b['name'] ?? '')); $main = trim((string)($b['main'] ?? 'index.js'));
      if ($name === '' || mb_strlen($name) > 40) out(['error' => 'Name must be 1-40 characters'], 422);
      if (!preg_match('/^(?!.*\.\.)[A-Za-z0-9_\-\/]{1,60}\.js$/', $main)) out(['error' => 'Startup file must end in .js (letters, numbers, - _ /)'], 422);
      $c = $db->prepare('SELECT COUNT(*) c FROM servers WHERE user_id=? AND expires>?'); $c->execute([$uid, time()]);
      if ((int)$c->fetch()['c'] >= $cfg['max']) out(['error' => 'You already have ' . $cfg['max'] . ' active servers. Wait for one to expire.'], 429);
      $sid = bin2hex(random_bytes(4)); $exp = time() + $cfg['hours'] * 3600;
      $r = W('POST', '/create/' . $sid, ['expires' => $exp]);
      if ($r[0] !== 200) out(['error' => $r[1]['error'] ?? 'Worker failed to create the server'], 502);
      $db->prepare('INSERT INTO servers(id,user_id,name,main,created,expires) VALUES(?,?,?,?,?,?)')->execute([$sid, $uid, $name, $main, time(), $exp]);
      out(['ok' => true, 'id' => $sid]);
    case 'power':
      $s = own($id); $op = (string)($b['op'] ?? '');
      if ($op === 'stop') relay(W('POST', '/stop/' . $id, []));
      if ($op === 'start' || $op === 'restart') relay(W('POST', '/start/' . $id, ['main' => $s['main']]));
      out(['error' => 'Unknown action'], 422);
    case 'status': $s = own($id); [$c, $st] = W('GET', '/status/' . $id); out(['server' => ['id' => $id, 'name' => $s['name'], 'main' => $s['main'], 'expires' => (int)$s['expires']], 'worker' => $c === 200 ? $st : null, 'error' => $c === 200 ? null : ($st['error'] ?? 'Worker error'), 'now' => time()]);
    case 'logs': own($id); relay(W('GET', '/logs/' . $id));
    case 'files': own($id); relay(W('GET', '/files/' . $id));
    case 'file': own($id); relay(W('GET', '/file/' . $id . '/' . rawurlencode((string)($_GET['name'] ?? ''))));
    case 'save': own($id); relay(W('POST', '/save/' . $id, ['name' => (string)($b['name'] ?? ''), 'content' => (string)($b['content'] ?? '')]));
    case 'envkeys': own($id); relay(W('GET', '/envkeys/' . $id));
    case 'env': own($id); relay(W('POST', '/setenv/' . $id, ['text' => (string)($b['text'] ?? '')]));
    default: out(['error' => 'Unknown endpoint'], 404);
  }
}
$me = !empty($_SESSION['uid']) ? ['name' => $_SESSION['name']] : null;
?><!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="csrf" content="<?= htmlspecialchars($_SESSION['csrf']) ?>"><title>Flux Host Panel</title>
<link rel="stylesheet" href="app.css"></head>
<body><div id="app"></div><div id="toast" role="status"></div>
<script>window.ME=<?= json_encode($me) ?>;window.HOURS=<?= (int)$cfg['hours'] ?>;</script>
<script src="app.js"></script></body></html>
