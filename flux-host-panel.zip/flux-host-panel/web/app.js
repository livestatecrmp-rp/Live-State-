'use strict';
const $ = s => document.querySelector(s), app = $('#app');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const CSRF = document.querySelector('meta[name=csrf]').content;
let poll = null, clock = null, skew = 0;

async function api(a, body, q) {
  const url = '?a=' + a + (q ? '&' + new URLSearchParams(q) : '');
  try {
    const r = await fetch(url, { method: body ? 'POST' : 'GET', headers: { 'X-CSRF': CSRF, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({ error: 'Unexpected response from server' }));
    if (!r.ok && !j.error) j.error = 'Error ' + r.status;
    return j;
  } catch { return { error: 'Cannot reach the website. Check your connection.' }; }
}
let tt; function toast(t, bad) { const e = $('#toast'); e.textContent = t; e.className = 'show' + (bad ? ' bad' : ''); clearTimeout(tt); tt = setTimeout(() => e.className = '', 2600); }
function stopTimers() { clearInterval(poll); clearInterval(clock); }
const BADGE = { running: ['Running', 'on'], created: ['Starting', 'st'], restarting: ['Starting', 'st'], exited: ['Stopped', 'off'], offline: ['Not running', ''], unknown: ['Unknown', ''] };
const badge = (state, exp) => { const b = (exp && Date.now() / 1000 + skew >= exp && state !== 'running') ? ['Expired', 'off'] : (BADGE[state] || [state, '']); return `<span class="badge ${b[1]}">${b[0]}</span>`; };
const left = exp => { const s = Math.max(0, Math.floor(exp - (Date.now() / 1000 + skew))); return [Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60].map(n => String(n).padStart(2, '0')).join(':'); };
const bar = () => `<header><div class="logo"><i>F</i>Flux Host</div><div><a href="#/">Servers</a> &nbsp; <button class="btn" id="out">Log out</button></div></header>`;

function authView() {
  let mode = location.hash === '#register' ? 'register' : 'login';
  const draw = () => {
    app.innerHTML = `<main><div class="card"><div class="logo"><i>F</i>Flux Host</div>
    <h1 style="margin-top:14px">${mode === 'login' ? 'Log in' : 'Create your free account'}</h1>
    <p class="sub">Free hosting for Discord bots. Each allocation lasts ${HOURS} hours, then the bot stops. No uptime guarantee.</p>
    <form id="f"><label>Username<input name="username" autocomplete="username" required></label>
    <label>Password<input name="password" type="password" autocomplete="${mode === 'login' ? 'current-password' : 'new-password'}" required minlength="8"></label>
    <p class="err" id="e" style="display:none;margin-top:12px"></p>
    <div class="row" style="margin-top:16px"><button class="btn pri" id="go">${mode === 'login' ? 'Log in' : 'Register'}</button><a href="#" id="sw">${mode === 'login' ? 'Need an account? Register' : 'Have an account? Log in'}</a></div></form></div></main>`;
    $('#sw').onclick = e => { e.preventDefault(); mode = mode === 'login' ? 'register' : 'login'; draw(); };
    $('#f').onsubmit = async e => {
      e.preventDefault(); const go = $('#go'); go.disabled = true;
      const f = new FormData(e.target), r = await api(mode, { username: f.get('username'), password: f.get('password') });
      if (r.ok) return location.reload();
      $('#e').style.display = 'block'; $('#e').textContent = r.error; go.disabled = false;
    };
  };
  draw();
}

async function dash() {
  stopTimers();
  app.innerHTML = bar() + `<main><div class="card"><h2>Create a bot server</h2><p class="sub">Node.js 20. A starter discord.js bot is included. Allocation: ${HOURS} hours.</p>
  <form id="cf"><label>Server name<input name="name" maxlength="40" required placeholder="My bot"></label>
  <label>Startup file<input name="main" value="index.js" required></label>
  <div class="row" style="margin-top:14px"><button class="btn pri" id="cb">Create server</button></div></form></div><div id="list" class="card"><p class="sub">Loading…</p></div></main>`;
  $('#out').onclick = async () => { await api('logout', {}); location.reload(); };
  $('#cf').onsubmit = async e => {
    e.preventDefault(); const b = $('#cb'); b.disabled = true; b.textContent = 'Creating…';
    const f = new FormData(e.target), r = await api('create', { name: f.get('name'), main: f.get('main') });
    b.disabled = false; b.textContent = 'Create server';
    if (r.ok) { toast('Server created'); location.hash = '#/s/' + r.id; } else toast(r.error, true);
  };
  const load = async () => {
    const r = await api('servers'); if (r.error) { $('#list').innerHTML = `<p class="err">${esc(r.error)}</p>`; return; }
    skew = r.now - Date.now() / 1000;
    $('#list').innerHTML = r.servers.length ? '<h2>Your servers</h2>' + r.servers.map(s => `<div class="row" style="padding:12px 0;border-top:1px solid var(--bd)">
      <div><a href="#/s/${s.id}"><b>${esc(s.name)}</b></a><div class="sub mono">${s.id} · ${esc(s.main)}</div></div>
      <div style="text-align:right">${badge(s.state, s.expires)}<div class="sub mono" data-exp="${s.expires}"></div></div></div>`).join('')
      : '<h2>No servers yet</h2><p class="sub">Create your first bot server above.</p>';
    tickAll();
  };
  const tickAll = () => document.querySelectorAll('[data-exp]').forEach(e => e.textContent = (+e.dataset.exp - Date.now() / 1000 - skew > 0) ? left(+e.dataset.exp) + ' left' : 'expired');
  await load(); poll = setInterval(load, 10000); clock = setInterval(tickAll, 1000);
}

async function manage(id) {
  stopTimers(); let cur = null, exp = 0;
  app.innerHTML = bar() + `<main><div class="card"><div class="row"><h1 id="nm">Loading…</h1><span id="bd"></span></div><p class="sub mono" id="meta"></p>
  <div id="werr"></div>
  <div class="ctl"><button class="btn go" data-op="start">Start</button><button class="btn" data-op="restart">Restart</button><button class="btn stop" data-op="stop">Stop</button></div></div>
  <div class="card"><div class="row"><div><div class="sub">Allocation time left</div><div class="big mono" id="cd">--:--:--</div></div><div class="sub mono" id="us"></div></div>
  <p class="sub">When this reaches zero the bot is stopped and removed, even if you are logged out.</p></div>
  <div class="card"><h2>Console</h2><pre id="log">Waiting for logs…</pre></div>
  <div class="card"><h2>Files</h2><div class="chips" id="fl"></div>
  <label>File name<input id="fn" placeholder="index.js"></label><textarea id="fc" spellcheck="false" placeholder="Pick a file or type a new file name"></textarea>
  <div class="row" style="margin-top:12px"><button class="btn pri" id="sv">Save file</button><span class="sub">Text files up to 200 KB. Restart to apply changes.</span></div></div>
  <div class="card"><h2>Variables</h2><p class="sub">Secrets such as DISCORD_TOKEN go here. Values are never shown again after saving.</p>
  <div class="chips" id="ek"></div><label>KEY=value, one per line (replaces all variables)<textarea id="et" style="min-height:110px" placeholder="DISCORD_TOKEN=your-token"></textarea></label>
  <div class="row" style="margin-top:12px"><button class="btn pri" id="se">Save variables</button></div></div></main>`;
  $('#out').onclick = async () => { await api('logout', {}); location.reload(); };
  const refresh = async () => {
    const r = await api('status', null, { id }); if (r.error && !r.server) { toast(r.error, true); return; }
    skew = r.now - Date.now() / 1000; exp = r.server.expires;
    $('#nm').textContent = r.server.name; $('#meta').textContent = r.server.id + ' · ' + r.server.main + ' · Node.js 20';
    $('#werr').innerHTML = r.error ? `<p class="err" style="margin-top:12px">${esc(r.error)}</p>` : '';
    const w = r.worker; $('#bd').innerHTML = w ? badge(w.state, exp) : badge('unknown');
    $('#us').textContent = w && w.stats ? `CPU ${w.stats.cpu} · RAM ${w.stats.mem}` : (w && w.state === 'exited' ? 'Exit code ' + w.exit : '');
    const l = await api('logs', null, { id }); if (l.logs !== undefined) { const p = $('#log'), at = p.scrollTop + p.clientHeight >= p.scrollHeight - 20; p.textContent = l.logs || '(no output yet)'; if (at) p.scrollTop = p.scrollHeight; }
  };
  const files = async () => {
    const r = await api('files', null, { id }); if (r.error) return;
    $('#fl').innerHTML = r.files.map(f => `<span class="chip ${f.name === cur ? 'cur' : ''}" data-f="${esc(f.name)}">${esc(f.name)}</span>`).join('');
    document.querySelectorAll('[data-f]').forEach(c => c.onclick = async () => {
      const x = await api('file', null, { id, name: c.dataset.f }); if (x.error) return toast(x.error, true);
      cur = c.dataset.f; $('#fn').value = cur; $('#fc').value = x.content; files();
    });
  };
  const keys = async () => { const r = await api('envkeys', null, { id }); $('#ek').innerHTML = (r.keys || []).map(k => `<span class="chip">${esc(k)}</span>`).join('') || '<span class="sub">No variables set.</span>'; };
  document.querySelectorAll('[data-op]').forEach(b => b.onclick = async () => {
    b.disabled = true; const r = await api('power', { id, op: b.dataset.op }); b.disabled = false;
    r.ok ? toast('Command accepted') : toast(r.error || 'Failed', true); refresh();
  });
  $('#sv').onclick = async () => { const n = $('#fn').value.trim(); if (!n) return toast('Enter a file name', true);
    const r = await api('save', { id, name: n, content: $('#fc').value }); r.ok ? (toast('Saved ' + n), cur = n, files()) : toast(r.error, true); };
  $('#se').onclick = async () => { const r = await api('env', { id, text: $('#et').value }); if (r.ok) { $('#et').value = ''; toast('Variables saved'); keys(); } else toast(r.error, true); };
  await refresh(); files(); keys();
  poll = setInterval(refresh, 4000);
  clock = setInterval(() => { const s = exp - (Date.now() / 1000 + skew); $('#cd').textContent = exp ? (s > 0 ? left(exp) : 'EXPIRED') : '--:--:--'; }, 1000);
}

function route() {
  if (!window.ME) return authView();
  const m = location.hash.match(/^#\/s\/([a-f0-9]{8})$/);
  m ? manage(m[1]) : dash();
}
addEventListener('hashchange', route); route();
