# Flux Host – Panel

Bot server panel: users register, create a Node.js bot server (12h allocation, one active server per account),
start/stop/restart, live console, file editor, variables, delete, automatic expiry (worker removes the container even when logged out).

## Install (Ubuntu 24.04 VPS, as root)
    apt-get update && apt-get install -y unzip wget
    wget -O panel.zip https://github.com/USERNAME/REPO/archive/refs/heads/main.zip
    unzip -o panel.zip && cd REPO-main
    SITE_ORIGIN=https://yourdomain.com ./install.sh

`SITE_ORIGIN` is the address of the main website (no trailing slash). It allows the website's login/dashboard to talk to this panel.
Re-run the same command any time to update; keys and data are kept.

## Cloudflare
Panel subdomain (e.g. `panel`) -> AAAA record to the VPS IPv6, Proxied. Panel listens on port 80.
SSL/TLS mode: Flexible works out of the box; Full is fine too (origin serves HTTP).

## Notes
- Bots run in `node:20-alpine`: 512 MB RAM, 0.5 CPU, 128 processes, no capabilities, non-root, no host mounts except their own folder.
- Worker listens on 127.0.0.1 only; secret is in `/etc/fluxhost.env`. It runs as root (controls Docker), never expose it.
- Settings in `/etc/fluxhost.env` (ALLOC_HOURS, MAX_ACTIVE). After editing: `./install.sh` again.
- Logs: `journalctl -u fluxhost-worker`, `journalctl -u nginx`, `tail /var/log/nginx/error.log`.
