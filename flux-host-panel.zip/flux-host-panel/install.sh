#!/usr/bin/env bash
# Flux Host panel installer (Ubuntu 24.04, run as root). Safe to re-run: keeps keys and data.
# Usage:  SITE_ORIGIN=https://yourdomain.com ./install.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run as root."; exit 1; }
. /etc/os-release; [ "${VERSION_ID:-}" = "24.04" ] || { echo "Needs Ubuntu 24.04 (found ${PRETTY_NAME:-unknown})."; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"; APP=/opt/fluxhost; ENVF=/etc/fluxhost.env
step(){ echo -e "\n\033[1;35m[$1]\033[0m $2"; }

step 1/6 "Installing packages (Docker, Nginx, PHP-FPM, Node.js)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq docker.io nginx php-fpm php-sqlite3 php-curl php-mbstring nodejs curl openssl >/dev/null
systemctl enable --now docker nginx >/dev/null

step 2/6 "Pulling Node image"
docker pull node:20-alpine >/dev/null

step 3/6 "Copying files"
id fluxweb >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin fluxweb
mkdir -p "$APP/data" /var/lib/fluxhost
rm -rf "$APP/web" "$APP/worker"; cp -r "$SRC/web" "$SRC/worker" "$APP/"
chown -R root:root "$APP/web" "$APP/worker"; chmod -R a+rX "$APP/web" "$APP/worker"
chown -R fluxweb:fluxweb "$APP/data"; chmod 750 "$APP/data"

step 4/6 "Secrets and settings"
if [ ! -f "$ENVF" ]; then
  umask 077
  printf 'WORKER_KEY=%s\nWORKER_URL=http://127.0.0.1:3939\nWEB_DATA=%s/data\nALLOC_HOURS=12\nMAX_ACTIVE=1\nSITE_ORIGIN=\n' "$(openssl rand -hex 32)" "$APP" > "$ENVF"
fi
if [ -n "${SITE_ORIGIN:-}" ]; then sed -i "s|^SITE_ORIGIN=.*|SITE_ORIGIN=${SITE_ORIGIN%/}|" "$ENVF"; fi
chmod 640 "$ENVF"; chgrp fluxweb "$ENVF"
set -a; . "$ENVF"; set +a

step 5/6 "Configuring Nginx + PHP-FPM"
PHPV=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')
cat > /etc/php/$PHPV/fpm/pool.d/fluxhost.conf <<POOL
[fluxhost]
user = fluxweb
group = fluxweb
listen = /run/php/fluxhost.sock
listen.owner = www-data
listen.group = www-data
pm = ondemand
pm.max_children = 12
clear_env = yes
env[WORKER_KEY] = $WORKER_KEY
env[WORKER_URL] = $WORKER_URL
env[WEB_DATA] = $WEB_DATA
env[ALLOC_HOURS] = $ALLOC_HOURS
env[MAX_ACTIVE] = $MAX_ACTIVE
env[SITE_ORIGIN] = ${SITE_ORIGIN:-}
POOL
systemctl restart php$PHPV-fpm
# Real visitor IP behind Cloudflare (needed for login rate limiting)
{ for u in ips-v4 ips-v6; do curl -fsS "https://www.cloudflare.com/$u" | sed 's/^/set_real_ip_from /; s/$/;/'; echo; done; echo "real_ip_header CF-Connecting-IP;"; } > /etc/nginx/conf.d/cloudflare-realip.conf 2>/dev/null || rm -f /etc/nginx/conf.d/cloudflare-realip.conf
rm -f /etc/nginx/sites-enabled/default
cat > /etc/nginx/sites-available/fluxhost <<NGX
server {
  listen 80 default_server;
  listen [::]:80 default_server;
  server_name _;
  root $APP/web;
  index index.php;
  client_max_body_size 2m;
  add_header X-Content-Type-Options nosniff always;
  add_header X-Frame-Options DENY always;
  add_header Referrer-Policy strict-origin-when-cross-origin always;
  location / { try_files \$uri \$uri/ /index.php?\$query_string; }
  location ~ \.php\$ {
    include snippets/fastcgi-php.conf;
    fastcgi_pass unix:/run/php/fluxhost.sock;
    fastcgi_read_timeout 160s;
  }
  location ~ /\. { deny all; }
}
NGX
ln -sf /etc/nginx/sites-available/fluxhost /etc/nginx/sites-enabled/fluxhost
nginx -t && systemctl reload nginx

step 6/6 "Starting worker"
cat > /etc/systemd/system/fluxhost-worker.service <<UNIT
[Unit]
Description=Flux Host worker
After=docker.service
Requires=docker.service
[Service]
EnvironmentFile=$ENVF
ExecStart=/usr/bin/node $APP/worker/worker.js
Restart=always
RestartSec=2
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable fluxhost-worker >/dev/null; systemctl restart fluxhost-worker
sleep 2
curl -fs -H "X-Worker-Key: $WORKER_KEY" http://127.0.0.1:3939/health >/dev/null && echo "Worker : OK" || echo "Worker : NOT responding (journalctl -u fluxhost-worker)"
curl -fs -o /dev/null http://127.0.0.1/ && echo "Panel  : OK" || echo "Panel  : NOT responding (journalctl -u nginx)"
IP6=$(ip -6 addr show scope global | awk '/inet6/{print $2}' | cut -d/ -f1 | head -1)
echo -e "\nDone. Point your Cloudflare AAAA record (panel subdomain, Proxied) to: ${IP6:-<your IPv6>}"
echo "Panel is on port 80. SITE_ORIGIN is: ${SITE_ORIGIN:-$(grep ^SITE_ORIGIN= $ENVF | cut -d= -f2)}"
